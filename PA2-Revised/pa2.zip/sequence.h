//
// Created by Jose Luis Tejada on 2019-03-25.
//

#ifndef PA2_REVISED_SEQUENCE_H
#define PA2_REVISED_SEQUENCE_H
long *Generate_2p3q_Seq(int length, int *seq_size);

#endif //PA2_REVISED_SEQUENCE_H
